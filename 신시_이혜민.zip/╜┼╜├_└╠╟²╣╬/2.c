#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int main(void) {
   FILE*     fpInputImage = 0;
   FILE*     fpOutputImage = 0;
   unsigned char**   newInputImage = 0;
   unsigned char**   newOutputImage = 0;
   int**   transInputImageBuffer = 0;
   int i, j, s, t, n,m;
   int sum=0;

   //double array[3][3] = { { 1 ,1 ,1 },{ 1,1 ,1 },{ 1,1,1} };
   double array[3][3] = { { 1,2,1 },{ 0,0,0 },{ -1,-2,-1 } };
  
   fpInputImage = fopen("lena.img", "rb");

   newInputImage = (unsigned char**)malloc(sizeof(unsigned char*) * 512);
   for (i = 0; i<512; i++) {
      newInputImage[i] = (unsigned char*)malloc(sizeof(unsigned char) * 512);
   }
   newOutputImage = (unsigned char**)malloc(sizeof(unsigned char*) * 512);
   for (i = 0; i<512; i++) {
      newOutputImage[i] = (unsigned char*)malloc(sizeof(unsigned char) * 512);
   }
   transInputImageBuffer = (int**)malloc(sizeof(int*) * 512);
   for (i = 0; i<512; i++) {
      transInputImageBuffer[i] = (int*)malloc(sizeof(int) * 512);
   }

   for (i = 0; i<512; i++) {
      fread(newInputImage[i], sizeof(unsigned char), 512, fpInputImage);
   }



   for (i = 1; i < 511; i++) {
      for (j = 1; j < 511; j++) {
         transInputImageBuffer[i][j] = 0;
         for (s = -1; s <= 1; s++) {
            for (t = -1; t <= 1; t++) {
				 transInputImageBuffer[i][j] += (array[s + 1][t + 1] * newInputImage[i + s][j + 1]);
            }
         }
		 if(transInputImageBuffer[i][j]>225)
				transInputImageBuffer[i][j]=225;
		else if(transInputImageBuffer[i][j]<0)
					transInputImageBuffer[i][j]=0;
   
      }
   }
  

  

   for (i = 0; i<512; i++) {
      for (j = 0; j<512; j++) {
         newOutputImage[i][j] = (unsigned char)transInputImageBuffer[i][j];
      }
   }

  
   fpOutputImage = fopen("lena_LPF.img", "wb");

   for (i = 0; i<512; i++) {
      fwrite(newOutputImage[i], sizeof(unsigned char), 512, fpOutputImage);
   }
   
   fclose(fpInputImage);
   fclose(fpOutputImage);

   return 0;
}