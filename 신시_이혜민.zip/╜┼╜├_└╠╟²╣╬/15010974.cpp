#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void Low_Pass_Filter(unsigned char ** pLena, unsigned char** output)
{
	int i, j,n,m, x,y;
	int sum=0, sum2=0;
	int mask[9][2]={{-1,-1},{ -1,0}, {-1,1}, {0,-1},{0,0},{0,1},{1,-1},{1,0},{1,1}};

	for(i=0; i<512; i++) 
	{
		for(j=0;j<512; j++){
			for(n=i-1;n<9;n++){
				x=i+mask[n][0];
				y=j+mask[n][1];
				if(x>=0 && y>=0 && x<512 && y<512){
					sum+=pLena[x][y];
					output[i][j]=sum/9;
			}
		}
	}
}
}


unsigned char** memory_alloc2D(int height, int width)
{
	unsigned char** ppMem2D = 0;
	int j, i;
 // array of pointer
	ppMem2D = (unsigned char **)malloc(sizeof(unsigned char *)* height);
	*ppMem2D = (unsigned char *)malloc(sizeof(unsigned char)*(width*height));
	for (j=1; j< height; j++ )
	{
		ppMem2D[j] = ppMem2D[j-1] + width;
	}
	return ppMem2D;
}
int memory_free2D(unsigned char** memAlloc){
	if(memAlloc==0)
		return -1;

	free(memAlloc[0]);
	free(memAlloc);

	return 0;
}
int** memory_alloc2D_int(int height, int width){
	int** mem2D=0;
	int i,j;

	mem2D=(int**)malloc(sizeof(int*), height);
int main(void)
{
	FILE* inputImage=0;
	FILE* outputImage=0;
	unsigned char** ppInput=0;
	unsigned char** ppOutput=0;
	int** transInputBuffer=0;
	int i,j,s,t;

	double array[3][3]={{1,1,1},{1,1,1},{1,1,1}};
	inputImage=fopen("lena.img","rb");

	ppInput=(unsigned char**)malloc(sizeof(unsigned char*)*512);
	for(i=0;i<512;i++){
		ppInput[i]=(unsigned char*)malloc(sizeof(unsigned char)*512);
	}
	ppOutput

}

